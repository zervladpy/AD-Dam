package com.pepinho.programacion.biblioteca;

public class Constraints {
    final static public String DB_PATH = "\\Clase\\AD-DAM2\\Library\\database\\biblioteca";
}
